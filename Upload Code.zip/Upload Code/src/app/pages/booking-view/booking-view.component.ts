import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-view',
  templateUrl: './booking-view.component.html',
  styleUrls: ['./booking-view.component.css']
})
export class BookingViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
