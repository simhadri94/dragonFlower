import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor() { }
  from:number;
  to:number;
  showFeatured:boolean=false;

  RDNature = {
    name:"RD's Nature",
    cost:999,
    url:'http://www.thewildfire.in/wp-content/uploads/2018/04/Twelve-768x464.jpg'
  }

  shilhaandara = {
    name:"Shilhaandara",
    cost:1199,
    url:'http://www.thewildfire.in/wp-content/uploads/2018/07/4-768x436.png'
  }

  mangoMist={
    name:"Mango Mist",
    cost:1549,
    url:'http://www.thewildfire.in/wp-content/uploads/2018/04/mango-768x432.jpg'
  }

  windflower={
    name:"Windflower",
    cost:1499,
    url:'http://www.thewildfire.in/wp-content/uploads/2018/07/7-768x523.jpg'
  }

  elimResort={
    name:"Elim Resort",
    cost:1199,
    url:'http://www.thewildfire.in/wp-content/uploads/2018/04/elim1-768x288.png'
  }

  resorts:any[]=[this.RDNature,this.shilhaandara,this.windflower,this.mangoMist,this.elimResort];
  resortList:any[]=[];

  ngOnInit() {
  }

  searchResort(){
    console.log(this.from+" "+this.to)
    this.resortList=[];
    for(var i=0;i < this.resorts.length;i++){
      if(this.resorts[i].cost >= this.from && this.resorts[i].cost < this.to){
        this.resortList.push(this.resorts[i]);
      }
    }
    this.showFeatured=true;
    console.log(this.resortList)
  }



}
